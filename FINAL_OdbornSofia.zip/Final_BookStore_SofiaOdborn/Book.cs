﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Item;

namespace Final_BookStore_SofiaOdborn
{
    [Item("Book", false)]
    public class Book
    {
        public int Book_code { get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
        public char Format { get; set; } // h (hardcover), p (paperback), a (audio) and e (ebook) 
        public int? Pages { get; set; }
        public decimal Price { get; set; }
        public int Quantity_sold { get; set; }
        public int? Part { get; set; }
        public decimal Total_Revenue { get; set; }
        public int Quantity_bo { get; set; }

        
        public static Series operator + (Series s, Book b1)
        {
            s.Total_Sold = s.Total_Sold + b1.Quantity_sold;
            s.Total_Revenue = s.Total_Revenue + b1.Total_Revenue;
            return s;           
        }
    }
}

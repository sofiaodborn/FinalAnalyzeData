﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Item;

namespace Final_BookStore_SofiaOdborn
{
    [Item("Digital Book", true)]
    public class digitalBook : Book
    {
        public string File_format { get; set; }
        public string File_path { get; set; } // either mp3 or txt file,  info not added in database
    }
}

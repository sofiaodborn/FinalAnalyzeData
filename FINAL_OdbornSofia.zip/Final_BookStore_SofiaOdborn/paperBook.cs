﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Item;

namespace Final_BookStore_SofiaOdborn
{
    [Item("Paper Book", true)]
    public class paperBook : Book
    {
        public int Quantity_onhand { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final_BookStore_SofiaOdborn
{
    class SortBySoldRevenue : IComparer<Series>
    {
        public int Compare(Series x, Series y)
        {
            int result = x.Total_Sold.CompareTo(y.Total_Sold);
            if (result == 0)
            {
                result = x.Total_Revenue.CompareTo(y.Total_Revenue);
            }
            return result;
        }
    }
}

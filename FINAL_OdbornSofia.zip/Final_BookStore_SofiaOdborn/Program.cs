﻿using System;
using System.Collections.Generic;
using System.Data.Linq;
using System.Data.SqlClient;
using System.Linq;
using System.Threading;
using System.Text;
using System.Threading.Tasks;

namespace Final_BookStore_SofiaOdborn
{
    public delegate string myPointer(Book book, List<Series> series);
    class Program
    {
        // Program collects data from SQL database

        private static readonly string connString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\BookStore.mdf;"
                + "Integrated security=True";
        static void Main(string[] args)
        {

            string sqlSelectStatement = "SELECT s.Series_ID, s.Name, b.Book_ID, Title, Author, Book_variant_ID, Variant, Price, Quantity_sold, " +
                "Quantity_onhand, Pages, File_format, Part, File_path " +
                "FROM Series s " +
                "RIGHT JOIN Book b " +
                "ON s.Series_ID = b.Series_ID " +
                "JOIN Book_variant bv " +
                "ON b.Book_ID = bv.Book_ID";

            SqlConnection myConnection = new SqlConnection();
            myConnection.ConnectionString = connString;
            myConnection.Open();

            SqlCommand command = new SqlCommand(sqlSelectStatement, myConnection);
            SqlDataReader reader;
            reader = command.ExecuteReader();


        
            List<Series> series = new List<Series>(); // stores series objects
            List<Book> allBooks = new List<Book>(); // stores book objects

            char check_format;
            while (reader.Read())
            {
                check_format = Convert.ToChar(reader["Variant"]);
                if (check_format == 'p' || check_format == 'h') // paper book
                {
                    allBooks.Add(new paperBook()
                    {
                        Book_code = (int)reader["Book_variant_ID"],
                        Title = reader["Title"].ToString(),
                        Author = reader["Author"].ToString(),
                        Format = Convert.ToChar(reader["Variant"]),
                        Pages = (int)reader["Pages"],
                        Price = (decimal)reader["Price"],
                        Quantity_sold = (int)reader["Quantity_sold"],
                        Quantity_onhand = (int)reader["Quantity_onhand"],
                        Part = (reader["Part"] as int?) ?? null,
                        Total_Revenue = (int)reader["Quantity_sold"] * (decimal)reader["Price"]
                    });
                }

                if (check_format == 'a' || check_format == 'e') // digital book
                {
                    allBooks.Add(new digitalBook()
                    {
                        Book_code = (int)reader["Book_variant_ID"],
                        Title = reader["Title"].ToString(),
                        Author = reader["Author"].ToString(),
                        Format = Convert.ToChar(reader["Variant"]),
                        Pages = (reader["Pages"] as int?) ?? null,
                        Price = (decimal)reader["Price"],
                        Quantity_sold = (int)reader["Quantity_sold"],
                        File_format = reader["File_format"].ToString(),
                        File_path = reader["File_path"].ToString(),
                        Part = (reader["Part"] as int?) ?? null,
                        Total_Revenue = (int)reader["Quantity_sold"] * (decimal)reader["Price"]
                    });
                }

                if (reader["Series_ID"] != DBNull.Value)
                {
                    if (!series.Any(x => x.Series_ID == (int)reader["Series_ID"])) // checks if series object does not exists
                    {
                        series.Add(new Series() // adds new series object
                        {
                            Series_ID = (int)reader["Series_ID"],
                            Name = reader["Name"].ToString(),
                            books = new List<Book>()
                        });
                    }
                    Series tempSeries = series.Find(x => x.Series_ID == (int)reader["Series_ID"]);
                    Book tempBook = allBooks.Find(x => x.Book_code == (int)reader["Book_variant_ID"]);
                    tempSeries.books.Add(tempBook); // adds book to series                  
                }
            }


            int Grand_total_sold = 0;
            decimal Grand_total_revenue = 0;

            // Calculates Total_Revenue and Total_Sold for Series objects
            foreach (Series s in series)
            {
                Series temp = s;
                foreach (Book b in temp.books)
                {
                    temp = temp + b; // utilizes operator overloading:
                                     // temp.Total_Sold + b.Quantity_sold 
                                     // temp.Total_Revenue + b.Total_Revenue
                }
                Grand_total_sold += temp.Total_Sold;
                Grand_total_revenue += temp.Total_Revenue;
            }



            // SALES REPORT: Series
           
            SortBySoldRevenue sortBySoldRevenue = new SortBySoldRevenue();
            series.Sort(sortBySoldRevenue); // sorts series
            series.Reverse();

            string Series_ID = "Series ID";
            string Series_Name = "Series Name";
            string Total_Quantity_Sold = "Total Quantity Sold";
            string Total_Revenue = "Total Revenue";

            Console.WriteLine("SALES REPORT: SERIES");
            // Header
            Console.WriteLine("{0} | {1} | {2} | {3}", Series_ID.PadRight(10), Series_Name.PadRight(26), Total_Quantity_Sold.PadRight(10),
               Total_Revenue);
            Console.WriteLine("=============================================================================");

            // Column values
            foreach (Series s in series)
            {
                Console.WriteLine("{0}    {1}    {2}    {3}",
                s.Series_ID.ToString().PadRight(9), s.Name.ToString().PadRight(25), s.Total_Sold.ToString().PadRight(18),
                string.Format("{0:c}", s.Total_Revenue));
            }
            Console.WriteLine("                                         -----------------------------------");

            // Grand totals
            Console.WriteLine("{0}    {1}",
                Grand_total_sold.ToString().PadLeft(47),
                string.Format("{0:c}", Grand_total_revenue).PadLeft(24));





            // SALES REPORT: All books

            
            myPointer pointer = new myPointer(SeriesName);  // Delegate holds reference to method

            SortByCode sortByCode = new SortByCode();
            allBooks.Sort(sortByCode); // sorts books

            int Grand_total_sold_books = 0;
            decimal Grand_total_revenue_books = 0;

            string Book_ID = "ID";
            string Format = "B. Type";
            string Pages = "Pages";
            string Series = "Series";
            string Part = "Part";
            string Total_Quantity_Sold_b = "Q. Sold";
            string Total_Revenue_b = "T. Rev.";

            Console.WriteLine("\n\nSALES REPORT: ALL BOOKS");
            // Header
            Console.WriteLine("{0} | {1} | {2} | {3} | {4} | {5} | {6}", Book_ID.PadRight(2), 
                Format.PadRight(5), Pages.PadRight(5), Part.PadRight(5), Series.PadRight(8), Total_Quantity_Sold_b.PadRight(7),
                Total_Revenue_b.PadRight(10));
            Console.WriteLine("==============================================================");

            // Column values
            foreach (Book b in allBooks)
            {
                IAsyncResult asyncResult = pointer.BeginInvoke(b, series, null, null); // Invokes delegate
                string s = pointer.EndInvoke(asyncResult); // Receives result once SeriesName method is done executing

                Console.WriteLine("{0} {1} {2} {3} {4} {5} {6}",
                b.Book_code.ToString().PadRight(4),
                b.Format.ToString().PadRight(9), b.Pages.ToString().PadRight(7), b.Part.ToString().PadRight(7), 
                s.PadRight(15).Substring(0,7).PadRight(10), b.Quantity_sold.ToString().PadRight(9), 
                string.Format("{0:c}", b.Total_Revenue).PadRight(10));

                Grand_total_sold_books += b.Quantity_sold;
                Grand_total_revenue_books += b.Total_Revenue;
            }

            Console.WriteLine("                                         ----------------------");

            // Grand totals
            Console.WriteLine("{0} {1}",
                Grand_total_sold_books.ToString().PadLeft(47),
                string.Format("{0:c}", Grand_total_revenue_books).PadLeft(15));






            // SALES REPORT: Paper vs Digital 

            var formatsumdig = allBooks.OfType<digitalBook>();
            var formatsumpap = allBooks.OfType<paperBook>();


            var query = // gets number of sold digital books per Book Title
                (from book in formatsumdig
                 group book by new { book.Title } into newGroup
                 select new
                 {
                     newGroup.Key.Title,
                     Type = "D",
                     Quantity_Sold = newGroup.Sum(x => x.Quantity_sold)
                 })
                 .Union(from book in formatsumpap // gets number of sold paper books per Book Title
                        group book by new { book.Title } into newGroup
                          select new
                          {
                              newGroup.Key.Title,
                              Type = "P",
                              Quantity_Sold = newGroup.Sum(x => x.Quantity_sold)
                          }).OrderBy(x => x.Title).ThenBy(x => x.Type);


            var query_total =  // gets total number of sold books per category (paper/digital)
                from total in query
                group total by new { total.Type } into newGroup
                select new
                {
                    Total_D = newGroup.Sum(x => x.Quantity_Sold),
                    newGroup.Key.Type
                };


            string Book_title = "Book Title";
            string Quantity_sold = "Quantity Sold";
            string Type_pd = "P/D";


            Console.WriteLine("\n\nSALES REPORT: PAPER vs DIGITAL");
            // Header
            Console.WriteLine("{0} | {1} | {2}", Book_title.PadRight(47), Type_pd.PadRight(8), Quantity_sold);
            Console.WriteLine("==========================================================================");

            // Column values
            foreach (var group in query)
            {
                Console.WriteLine("{0} {1} {2}", group.Title.ToString().Trim().PadRight(49), 
                    group.Type.ToString().Trim().PadRight(10), group.Quantity_Sold.ToString().Trim());
            }
            Console.WriteLine("                                                 ------------------");

            // Grand totals
            foreach (var group in query_total)
                Console.WriteLine("{0} {1}",
                group.Type.ToString().Trim().PadLeft(51), group.Total_D.ToString().Trim().PadLeft(14));

            myConnection.Close();

            Console.WriteLine("\nPress <ENTER> to quit...");
            Console.ReadKey();
        }

        public static string SeriesName(Book b, List<Series> s) // If book belongs to a series, the name of the series is returned
        {
            Series temp = s.Find(x => x.books.Contains(b));

            if (temp == null)
            {
                return " ";
            }

            return temp.Name;
        }           
    }
}

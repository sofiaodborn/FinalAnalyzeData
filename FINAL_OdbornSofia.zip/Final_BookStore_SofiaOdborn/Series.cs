﻿
using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final_BookStore_SofiaOdborn
{
    public class Series
    {
        public int Series_ID { get; set; }
        public string Name { get; set; }
        public List<Book> books { get; set; } // stores books in series
        public decimal Total_Revenue { get; set; }
        public int Total_Sold { get; set; }

        }
    }  


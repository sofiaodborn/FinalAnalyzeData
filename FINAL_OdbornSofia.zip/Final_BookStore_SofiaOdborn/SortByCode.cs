﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final_BookStore_SofiaOdborn
{
    class SortByCode : IComparer<Book>
    {
        public int Compare(Book x, Book y)
        {
            int result = x.Book_code.CompareTo(y.Book_code);
            return result;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Item
{
    [AttributeUsage(AttributeTargets.Class)]
    public class ItemAttribute : Attribute
    {
        public string Name { get; set; }
        public bool Inheritor { get; set; }

        public ItemAttribute(string name, bool inheritor)
        {
            this.Name = name;
            this.Inheritor = inheritor;
        }
    }
}
